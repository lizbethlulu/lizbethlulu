// toggle class active hamburger menu
const menuBar = document.querySelector('.menu-bar');
//toggle class active search
// ketika hamburger menu diklik
document.querySelector('#hamburger_menu').onclick = () => {
    menuBar.classList.toggle('active');
};
const searchForm = document.querySelector('.search_form');
const searchBox = document.querySelector('#search-box');
// ketika search-button diklik
document.querySelector('#search-button').onclick = () => {
    searchForm.classList.toggle('active');
    searchBox.focus();
};
//klik diluar elemen
const hm = document.querySelector('#hamburger_menu');
const sb = document.querySelector('#search-button');

document.addEventListener('click', function(e) {
    if(!hm.contains(e.target) && !menuBar.contains(e.target)){
        menuBar.classList.remove('active');
    }
    if(!sb.contains(e.target) && !searchForm.contains(e.target)){
        searchForm.classList.remove('active');
    }
});

let popupContainer = document.querySelector('.food-popup');
let popupBox = popupContainer.querySelectorAll('.popup');

document.querySelectorAll('.food-box .food').forEach(food =>{
    food.onclick = () =>{
     popupContainer.style.display = 'flex';
        let name = food.getAttribute('data-name');
        popupBox.forEach(popup =>{
            let target = popup.getAttribute('data-target');
            if(name == target){
                popup.classList.add('active');
            }
        });
    };
});

popupBox.forEach(close =>{
    close.querySelector('.bx-x').onclick = () =>{
        close.classList.remove('active');
        popupContainer.style.display = 'none';
    }
});

let popupTruck = document.querySelector('.ftruck-popup');
let popupSmallTruck = popupTruck.querySelectorAll('.fpopup');

document.querySelectorAll('.food-truck .ftruck').forEach(ftruck =>{
    ftruck.onclick = () =>{
     popupTruck.style.display = 'flex';
        let name_2 = ftruck.getAttribute('data-name');
        popupSmallTruck.forEach(fpopup =>{
            let target_2 = fpopup.getAttribute('data-target');
            if(name_2 == target_2){
                fpopup.classList.add('active');
            }
        });
    };
});

popupSmallTruck.forEach(close =>{
    close.querySelector('.bx-x').onclick = () =>{
        close.classList.remove('active');
        popupTruck.style.display = 'none';
    }
});

let popupaTruck = document.querySelector('.atruck-popup');
let popupSmallaTruck = popupaTruck.querySelectorAll('.apopup');

document.querySelectorAll('.appetizer-truck .atruck').forEach(atruck =>{
    atruck.onclick = () =>{
     popupaTruck.style.display = 'flex';
        let name_3 = atruck.getAttribute('data-name');
        popupSmallaTruck.forEach(apopup =>{
            let target_3 = apopup.getAttribute('data-target');
            if(name_3 == target_3){
                apopup.classList.add('active');
            }
        });
    };
});

popupSmallaTruck.forEach(close =>{
    close.querySelector('.bx-x').onclick = () =>{
        close.classList.remove('active');
        popupaTruck.style.display = 'none';
    }
});

let popupContainer4 = document.querySelector('.a4-popup');
let popupBox4 = popupContainer4.querySelectorAll('.a4popup');

document.querySelectorAll('.a4-truck .a4truck').forEach(a4truck =>{
    a4truck.onclick = () =>{
     popupContainer4.style.display = 'flex';
        let name4 = a4truck.getAttribute('data-name');
        popupBox4.forEach(a4popup =>{
            let target4 = a4popup.getAttribute('data-target');
            if(name4 == target4){
                a4popup.classList.add('active');
            }
        });
    };
});

popupBox4.forEach(close =>{
    close.querySelector('.bx-x').onclick = () =>{
        close.classList.remove('active');
        popupContainer4.style.display = 'none';
    }
});

let popupContainer5 = document.querySelector('.a5-popup');
let popupBox5 = popupContainer5.querySelectorAll('.a5popup');

document.querySelectorAll('.a5-truck .a5truck').forEach(a5truck =>{
    a5truck.onclick = () =>{
     popupContainer5.style.display = 'flex';
        let name5 = a5truck.getAttribute('data-name');
        popupBox5.forEach(a5popup =>{
            let target5 = a5popup.getAttribute('data-target');
            if(name5 == target5){
                a5popup.classList.add('active');
            }
        });
    };
});

popupBox5.forEach(close =>{
    close.querySelector('.bx-x').onclick = () =>{
        close.classList.remove('active');
        popupContainer5.style.display = 'none';
    }
});

